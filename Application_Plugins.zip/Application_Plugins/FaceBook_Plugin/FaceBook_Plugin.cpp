#include "FaceBook_Plugin.h"

void FaceBook_Plugin::readPlugins(QString facebook)
{
    QString fbString="myFacebook";
    if(facebook.compare(fbString))
    {
        fb_inside();
        qDebug()<<"******FaceBook___app_____found________"<<Qt::endl;
    }
}

void FaceBook_Plugin::fb_inside()
{
  qDebug()<<"*******FaceBook___Plugin____Is__Created__*********"<<Qt::endl;
}

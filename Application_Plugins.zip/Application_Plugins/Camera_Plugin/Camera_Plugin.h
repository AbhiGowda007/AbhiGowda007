#ifndef CAMERA_PLUGIN_H
#define CAMERA_PLUGIN_H

#include "Camera_Plugin_global.h"
#include<Interface_Appplication_Plugin.h>
#include<QDebug>
#include<QObject>

class CAMERA_PLUGIN_EXPORT Camera_Plugin:public QObject,public Interface_Appplication_Plugin
{
    Q_OBJECT
    Q_INTERFACES(Interface_Appplication_Plugin)
    Q_PLUGIN_METADATA(IID Interface_Appplication_Plugin_IID)
public:
    explicit Camera_Plugin(QObject *parent = nullptr)
    {};
        void readPlugins(QString) override;
        void camera_inside();

};

#endif // CAMERA_PLUGIN_H

#include "Camera_Plugin.h"



void Camera_Plugin::readPlugins(QString camera)
{
    QString cameraString="mycamera";
    if(camera.compare(cameraString))
    {
        camera_inside();
        qDebug()<<"******Camera___app_____found________"<<Qt::endl;
    }
}

void Camera_Plugin::camera_inside()
{
    qDebug()<<"*******Camera___Plugin____Is__Created__*********"<<Qt::endl;
}

#ifndef CAMERA_PLUGIN_GLOBAL_H
#define CAMERA_PLUGIN_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(CAMERA_PLUGIN_LIBRARY)
#  define CAMERA_PLUGIN_EXPORT Q_DECL_EXPORT
#else
#  define CAMERA_PLUGIN_EXPORT Q_DECL_IMPORT
#endif

#endif // CAMERA_PLUGIN_GLOBAL_H

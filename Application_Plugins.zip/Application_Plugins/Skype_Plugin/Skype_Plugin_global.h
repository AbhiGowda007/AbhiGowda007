#ifndef SKYPE_PLUGIN_GLOBAL_H
#define SKYPE_PLUGIN_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(SKYPE_PLUGIN_LIBRARY)
#  define SKYPE_PLUGIN_EXPORT Q_DECL_EXPORT
#else
#  define SKYPE_PLUGIN_EXPORT Q_DECL_IMPORT
#endif

#endif // SKYPE_PLUGIN_GLOBAL_H

#include "Skype_Plugin.h"

void Skype_Plugin::readPlugins(QString skype)
{
    QString skypeString="mySkype";
    if(skype.compare(skypeString))
    {
        skype_inside();
        qDebug()<<"******Skype___app_____found________"<<Qt::endl;
    }
}

void Skype_Plugin::skype_inside()
{
    qDebug()<<"*******Skype___Plugin____Is__Created__*********"<<Qt::endl;
}

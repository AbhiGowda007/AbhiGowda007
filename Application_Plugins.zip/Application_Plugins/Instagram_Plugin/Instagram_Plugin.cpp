#include "Instagram_Plugin.h"


void Instagram_Plugin::readPlugins(QString instagram)
{
    QString instaString="myInstagram";
    if(instagram.compare(instaString))
    {
        insta_inside();
        qDebug()<<"******Instagram___app_____found________"<<Qt::endl;
    }
}

void Instagram_Plugin::insta_inside()
{
 qDebug()<<"*******Instagram___Plugin____Is__Created__*********"<<Qt::endl;
}

#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include<Manage_Plugin.h>
#include<Interface_Appplication_Plugin.h>
#include<QQmlContext>

int main(int argc, char *argv[])
{


#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif

    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
    Manage_Plugin manage;
    QQmlContext *context=engine.rootContext();
    context->setContextProperty("use_Plugin",&manage);

//    manage.get_Plugins("");
    manage.setFolderPath("E://Application_Plugins//bin");
    manage.checkPlugins(qApp->applicationDirPath());




    const QUrl url(QStringLiteral("qrc:/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}

#ifndef MANAGE_PLUGIN_H
#define MANAGE_PLUGIN_H

#include <QObject>
#include<Interface_Appplication_Plugin.h>
#include<QDebug>
#include<QString>
#include<QDir>
#include <QFile>
#include <QFileInfo>



class Manage_Plugin : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString my_Plugins READ getFolderPath WRITE setFolderPath NOTIFY my_PluginChanged)
public:

    explicit Manage_Plugin(QObject *parent = nullptr);

    const QString &getFolderPath() const;
    void setFolderPath(const QString &newFolderPath);

    Q_INVOKABLE void get_Plugins(QString);

    void checkPlugins(QString);
    void read_Dll(QString);


private:
    QDir m_directory;
    QString folderPath;



signals:
    void my_PluginChanged();

};

#endif // MANAGE_PLUGIN_H

#include "Manage_Plugin.h"
#include<QPluginLoader>

Manage_Plugin::Manage_Plugin(QObject *parent) : QObject(parent)
{
    qDebug()<<"Manage_Plugin constructor is called"<<Qt::endl;
}

void Manage_Plugin::checkPlugins(QString path)
{
    m_directory.setPath(path);
    qDebug()<<"*************pathhhhh=======***************==="<<path<<Qt::endl;
    QStringList  files = m_directory.entryList(QStringList()<<"*.dll",QDir::Files);
    qDebug()<<"*************====filesssss===***************==="<<files<<Qt::endl;
    for(int i=0;i<files.length();i++)
    {
        if(files[i]=="Interface_Appplication_Plugin.dll")
            continue;
        qDebug()<<"*************My_FIles_Name=======***************==="<<files[i]<<Qt::endl;
        QString dllPath=path+"/"+files[i];
        qDebug()<<"******************Dllpath****************======"<<dllPath;
        read_Dll(dllPath);
    }
}
void Manage_Plugin::read_Dll(QString filename)
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    QPluginLoader loadPlugin;
    loadPlugin.setFileName(filename);
    if(!loadPlugin.load())
    {
        qDebug()<<"*****Plugin_Not_Found*****"<<Qt::endl;
        return;
    }
    else
    {
        qDebug()<< Q_FUNC_INFO <<"*************************PluginFound*************************"<<Qt::endl;
    }
    QObject *obj=loadPlugin.instance();
    Interface_Appplication_Plugin* myObject=qobject_cast<Interface_Appplication_Plugin*>(obj);
    myObject->readPlugins(folderPath);
    return;

}
const QString &Manage_Plugin::getFolderPath() const
{
    return folderPath;
}

void Manage_Plugin::setFolderPath(const QString &newFolderPath)
{
    folderPath = newFolderPath;
}

Q_INVOKABLE void Manage_Plugin::get_Plugins(QString myfilename)
{
    qDebug()<<"*********************in side my_pluginsssssss*************"<<Qt::endl;
    if(myfilename=="cali")
    {
        qDebug()<<"***********My____File__Nmaeeeeeee***************"<<myfilename<<Qt::endl;
        qDebug()<<"***********calculator application found***************"<<Qt::endl;
        QPluginLoader calciloader;
        calciloader.setFileName("Calculator_Plugin.dll");
        qDebug()<<"***********calculator dll loaded***************"<<Qt::endl;
        QObject *obj=calciloader.instance();
        Interface_Appplication_Plugin* myObject=qobject_cast<Interface_Appplication_Plugin*>(obj);
        myObject->readPlugins(myfilename);
        qDebug()<<"***********calculator  plugin called***************"<<Qt::endl;
        return;
    }
    if (myfilename=="calender")
    {
        qDebug()<<"***********calender application found***************"<<Qt::endl;
        QPluginLoader calenderloader;
        calenderloader.setFileName("Calender_Plugin.dll");
        qDebug()<<"***********Calender dll loaded***************"<<Qt::endl;
        QObject *obj=calenderloader.instance();
        Interface_Appplication_Plugin* myObject=qobject_cast<Interface_Appplication_Plugin*>(obj);
        myObject->readPlugins(myfilename);
        return;
    }
    if(myfilename=="camera")
    {
        qDebug()<<"***********Camera application found***************"<<Qt::endl;
        QPluginLoader cameraloader;
        cameraloader.setFileName("Camera_Plugin.dll");
        QObject *obj=cameraloader.instance();
        Interface_Appplication_Plugin* myObject=qobject_cast<Interface_Appplication_Plugin*>(obj);
        myObject->readPlugins(myfilename);
        return;
    }
    if(myfilename=="crome")
    {
        qDebug()<<"***********Crome application found***************"<<Qt::endl;
        QPluginLoader cromeloader;
        cromeloader.setFileName("Chrome_Plugin.dll");
        qDebug()<<"***********Chrome dll loaded***************"<<Qt::endl;
        QObject *obj=cromeloader.instance();
        Interface_Appplication_Plugin* myObject=qobject_cast<Interface_Appplication_Plugin*>(obj);
        myObject->readPlugins(myfilename);
        return;
    }
    if(myfilename=="facebook")
    {
        qDebug()<<"***********FaceBook application found***************"<<Qt::endl;
        QPluginLoader facebookloader;
        facebookloader.setFileName("FaceBook_Plugin.dll");
        qDebug()<<"***********Facebook dll loaded***************"<<Qt::endl;
        QObject *obj=facebookloader.instance();
        Interface_Appplication_Plugin* myObject=qobject_cast<Interface_Appplication_Plugin*>(obj);
        myObject->readPlugins(myfilename);
        return;
    }
    if(myfilename=="gallery")
    {
        qDebug()<<"***********Gallery application found***************"<<Qt::endl;
        QPluginLoader galleryloader;
        galleryloader.setFileName("Gallery_Plugin.dll");
        qDebug()<<"***********Gallery dll loaded***************"<<Qt::endl;
        QObject *obj=galleryloader.instance();
        Interface_Appplication_Plugin* myObject=qobject_cast<Interface_Appplication_Plugin*>(obj);
        myObject->readPlugins(myfilename);
        return;
    }
    if(myfilename=="google")
    {
        qDebug()<<"***********Google application found***************"<<Qt::endl;
        QPluginLoader googleloader;
        googleloader.setFileName("Google_Plugin.dll");
        qDebug()<<"***********Google dll loaded***************"<<Qt::endl;
        QObject *obj=googleloader.instance();
        Interface_Appplication_Plugin* myObject=qobject_cast<Interface_Appplication_Plugin*>(obj);
        myObject->readPlugins(myfilename);
        return;
    }
    if(myfilename=="instagram")
    {
        qDebug()<<"***********Instagram application found***************"<<Qt::endl;
        QPluginLoader instaloader;
        instaloader.setFileName("Instagram_Plugin.dll");
        qDebug()<<"***********Instagram dll loaded***************"<<Qt::endl;
        QObject *obj=instaloader.instance();
        Interface_Appplication_Plugin* myObject=qobject_cast<Interface_Appplication_Plugin*>(obj);
        myObject->readPlugins(myfilename);
        return;
    }

    if(myfilename=="link")
    {
        qDebug()<<"***********Linked_In application found***************"<<Qt::endl;
        QPluginLoader linkloader;
        linkloader.setFileName("Linked_In_Plugin.dll");
        qDebug()<<"***********Linked_IN dll loaded***************"<<Qt::endl;
        QObject *obj=linkloader.instance();
        Interface_Appplication_Plugin* myObject=qobject_cast<Interface_Appplication_Plugin*>(obj);
        myObject->readPlugins(myfilename);
        return;
    }

    if(myfilename=="phonePe")
    {
        qDebug()<<"***********Phone_Pe application found***************"<<Qt::endl;
        QPluginLoader phoneloader;
        phoneloader.setFileName("Phone_PE_Plugin.dll");
        qDebug()<<"***********Phone_PE dll loaded***************"<<Qt::endl;
        QObject *obj=phoneloader.instance();
        Interface_Appplication_Plugin* myObject=qobject_cast<Interface_Appplication_Plugin*>(obj);
        myObject->readPlugins(myfilename);
        return;
    }
    if(myfilename=="pubg")
    {
        qDebug()<<"***********PUBG application found***************"<<Qt::endl;
        QPluginLoader pubgloader;
        pubgloader.setFileName("PUBG_Plugin.dll");
        qDebug()<<"***********PUBG dll loaded***************"<<Qt::endl;;
        QObject *obj=pubgloader.instance();
        Interface_Appplication_Plugin* myObject=qobject_cast<Interface_Appplication_Plugin*>(obj);
        myObject->readPlugins(myfilename);
        return;
    }
    if(myfilename=="skype")
    {
        qDebug()<<"***********Skype application found***************"<<Qt::endl;
        QPluginLoader skypeloader;
        skypeloader.setFileName("Skype_Plugin.dll");
        qDebug()<<"***********Skype dll loaded***************"<<Qt::endl;
        QObject *obj=skypeloader.instance();
        Interface_Appplication_Plugin* myObject=qobject_cast<Interface_Appplication_Plugin*>(obj);
        myObject->readPlugins(myfilename);
        return;
    }



}

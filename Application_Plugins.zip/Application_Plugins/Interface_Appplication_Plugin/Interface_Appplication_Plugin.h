#ifndef INTERFACE_APPPLICATION_PLUGIN_H
#define INTERFACE_APPPLICATION_PLUGIN_H

#include<QtPlugin>
#include<QString>
#define Interface_Appplication_Plugin_IID "com.abishek.1.0"

class  Interface_Appplication_Plugin
{
public:

    virtual void readPlugins(QString)=0;

};
Q_DECLARE_INTERFACE(Interface_Appplication_Plugin,Interface_Appplication_Plugin_IID)

#endif // INTERFACE_APPPLICATION_PLUGIN_H

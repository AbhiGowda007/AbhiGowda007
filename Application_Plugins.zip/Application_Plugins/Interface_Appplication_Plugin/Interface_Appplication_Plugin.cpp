#include "Interface_Appplication_Plugin.h"

Interface_Appplication_Plugin::Interface_Appplication_Plugin()
{
}

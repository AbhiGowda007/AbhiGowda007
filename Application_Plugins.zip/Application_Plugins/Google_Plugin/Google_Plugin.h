#ifndef GOOGLE_PLUGIN_H
#define GOOGLE_PLUGIN_H

#include "Google_Plugin_global.h"
#include<Interface_Appplication_Plugin.h>
#include<QDebug>
#include<QObject>

class GOOGLE_PLUGIN_EXPORT Google_Plugin:public QObject,public Interface_Appplication_Plugin
{
    Q_OBJECT
    Q_INTERFACES(Interface_Appplication_Plugin)
    Q_PLUGIN_METADATA(IID Interface_Appplication_Plugin_IID)
public:
    explicit Google_Plugin(QObject *parent = nullptr)
    {};
    void readPlugins(QString) override;
    void google_inside();
};

#endif // GOOGLE_PLUGIN_H

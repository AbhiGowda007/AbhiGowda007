#include "Google_Plugin.h"

void Google_Plugin::readPlugins(QString google)
{
    QString googleString="myGoogle";
    if(google.compare(googleString))
    {
        google_inside();
        qDebug()<<"******Google___app_____found________"<<Qt::endl;
    }
}

void Google_Plugin::google_inside()
{
    qDebug()<<"*******Google___Plugin____Is__Created__*********"<<Qt::endl;
}

#ifndef GOOGLE_PLUGIN_GLOBAL_H
#define GOOGLE_PLUGIN_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(GOOGLE_PLUGIN_LIBRARY)
#  define GOOGLE_PLUGIN_EXPORT Q_DECL_EXPORT
#else
#  define GOOGLE_PLUGIN_EXPORT Q_DECL_IMPORT
#endif

#endif // GOOGLE_PLUGIN_GLOBAL_H

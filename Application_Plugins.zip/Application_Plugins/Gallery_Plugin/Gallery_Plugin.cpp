#include "Gallery_Plugin.h"

void Gallery_Plugin::readPlugins(QString gallery)
{
    QString galeryString="myGallery";
    if(gallery.compare(galeryString))
    {
        gallery_inside();
        qDebug()<<"******Gallery___app_____found________"<<Qt::endl;
    }
}

void Gallery_Plugin::gallery_inside()
{
    qDebug()<<"*******Gallery___Plugin____Is__Created__*********"<<Qt::endl;
}


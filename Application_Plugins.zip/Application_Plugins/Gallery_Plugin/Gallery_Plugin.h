#ifndef GALLERY_PLUGIN_H
#define GALLERY_PLUGIN_H

#include "Gallery_Plugin_global.h"
#include<Interface_Appplication_Plugin.h>
#include<QDebug>
#include<QObject>

class GALLERY_PLUGIN_EXPORT Gallery_Plugin:public QObject,public Interface_Appplication_Plugin
{
    Q_OBJECT
    Q_INTERFACES(Interface_Appplication_Plugin)
    Q_PLUGIN_METADATA(IID Interface_Appplication_Plugin_IID)
public:
    explicit Gallery_Plugin(QObject *parent = nullptr)
    {};
    void readPlugins(QString) override;
    void gallery_inside();
};

#endif // GALLERY_PLUGIN_H

#include "Manage_Plugin.h"
#include<Interface_Appplication_Plugin.h>
#include <QApplication>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Manage_Plugin manage;

    manage.setFolderPath("E:/Application_Plugins/bin");
    manage.checkPlugins(qApp->applicationDirPath());
    return a.exec();
}

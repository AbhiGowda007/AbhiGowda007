#ifndef MANAGE_PLUGIN_H
#define MANAGE_PLUGIN_H

#include <QWidget>
#include <QObject>
#include<Interface_Appplication_Plugin.h>
#include<QDebug>
#include<QString>
#include<QDir>
#include <QFile>
#include <QFileInfo>

class Manage_Plugin : public QWidget
{
    Q_OBJECT

public:
    Manage_Plugin(QWidget *parent = nullptr);
    ~Manage_Plugin();

    void checkPlugins(QString);

    const QString &getFolderPath() const;
    void setFolderPath(const QString &newFolderPath);

private:
     QDir m_directory;
     QString folderPath;
};
#endif // MANAGE_PLUGIN_H

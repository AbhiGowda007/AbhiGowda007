#include "Manage_Plugin.h"

Manage_Plugin::Manage_Plugin(QWidget *parent)
    : QWidget(parent)
{
    qDebug()<<"Manage_Plugin constructor is called"<<Qt::endl;
}

Manage_Plugin::~Manage_Plugin()
{
}

const QString &Manage_Plugin::getFolderPath() const
{
    return folderPath;
}

void Manage_Plugin::setFolderPath(const QString &newFolderPath)
{
    folderPath = newFolderPath;
}
void Manage_Plugin::checkPlugins(QString path)
{
    m_directory.setPath(path);
    qDebug()<<"*************pathhhhh=======***************==="<<path<<Qt::endl;
    QStringList  files = m_directory.entryList(QStringList()<<"*.dll",QDir::Files);
    qDebug()<<"*************====filesssss===***************==="<<files<<Qt::endl;
}


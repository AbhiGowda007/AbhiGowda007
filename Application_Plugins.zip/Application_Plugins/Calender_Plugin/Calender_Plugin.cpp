#include "Calender_Plugin.h"
void Calender_Plugin::readPlugins(QString calender)
{
    QString calenderString="mycalender";
    if(calender.compare(calenderString))
    {
        calender_inside();
        qDebug()<<"******Calender___app_____found________"<<Qt::endl;
    }
}
void Calender_Plugin::calender_inside()
{
    qDebug()<<"*******Calender___Plugin____Is__Created__*********"<<Qt::endl;
}

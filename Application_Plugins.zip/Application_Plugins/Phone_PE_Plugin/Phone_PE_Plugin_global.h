#ifndef PHONE_PE_PLUGIN_GLOBAL_H
#define PHONE_PE_PLUGIN_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(PHONE_PE_PLUGIN_LIBRARY)
#  define PHONE_PE_PLUGIN_EXPORT Q_DECL_EXPORT
#else
#  define PHONE_PE_PLUGIN_EXPORT Q_DECL_IMPORT
#endif

#endif // PHONE_PE_PLUGIN_GLOBAL_H

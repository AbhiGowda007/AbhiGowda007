#ifndef PHONE_PE_PLUGIN_H
#define PHONE_PE_PLUGIN_H

#include "Phone_PE_Plugin_global.h"
#include<Interface_Appplication_Plugin.h>
#include<QDebug>
#include<QObject>

class PHONE_PE_PLUGIN_EXPORT Phone_PE_Plugin:public QObject,public Interface_Appplication_Plugin
{
    Q_OBJECT
    Q_INTERFACES(Interface_Appplication_Plugin)
    Q_PLUGIN_METADATA(IID Interface_Appplication_Plugin_IID)
public:
    explicit Phone_PE_Plugin(QObject *parent = nullptr)
    {};
    void readPlugins(QString) override;
    void phonePe_inside();
};

#endif // PHONE_PE_PLUGIN_H

#include "Phone_PE_Plugin.h"

void Phone_PE_Plugin::readPlugins(QString phonePe)
{
    QString phoneString="myPhonePe";
    if(phonePe.compare(phoneString))
    {
        phonePe_inside();
        qDebug()<<"******PhonePe___app_____found________"<<Qt::endl;
    }
}

void Phone_PE_Plugin::phonePe_inside()
{
    qDebug()<<"*******PhonePe___Plugin____Is__Created__*********"<<Qt::endl;
}

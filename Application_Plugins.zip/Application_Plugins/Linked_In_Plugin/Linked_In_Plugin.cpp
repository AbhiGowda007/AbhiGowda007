#include "Linked_In_Plugin.h"


void Linked_In_Plugin::readPlugins(QString link)
{
    QString linkedString="myLinkedin";
    if(link.compare(linkedString))
    {
        linkedin_inside();
        qDebug()<<"******Linked_IN___app_____found________"<<Qt::endl;
    }
}

void Linked_In_Plugin::linkedin_inside()
{
 qDebug()<<"*******LinkedIn___Plugin____Is__Created__*********"<<Qt::endl;
}

#ifndef LINKED_IN_PLUGIN_H
#define LINKED_IN_PLUGIN_H

#include "Linked_In_Plugin_global.h"
#include<Interface_Appplication_Plugin.h>
#include<QDebug>
#include<QObject>

class LINKED_IN_PLUGIN_EXPORT Linked_In_Plugin:public QObject,public Interface_Appplication_Plugin
{
    Q_OBJECT
    Q_INTERFACES(Interface_Appplication_Plugin)
    Q_PLUGIN_METADATA(IID Interface_Appplication_Plugin_IID)
public:

    explicit Linked_In_Plugin(QObject *parent = nullptr)
    {};
    void readPlugins(QString link) override;
    void linkedin_inside();
};

#endif // LINKED_IN_PLUGIN_H

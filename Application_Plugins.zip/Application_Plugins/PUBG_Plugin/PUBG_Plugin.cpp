#include "PUBG_Plugin.h"

void PUBG_Plugin::readPlugins(QString pubg)
{
    QString pubgString="myPubg";
    if(pubg.compare(pubgString))
    {
        pubg_inside();
        qDebug()<<"******PUBG___app_____found________"<<Qt::endl;
    }
}

void PUBG_Plugin::pubg_inside()
{
qDebug()<<"*******PUBG___Plugin____Is__Created__*********"<<Qt::endl;
}

#ifndef PUBG_PLUGIN_H
#define PUBG_PLUGIN_H

#include "PUBG_Plugin_global.h"
#include<Interface_Appplication_Plugin.h>
#include<QDebug>
#include<QObject>

class PUBG_PLUGIN_EXPORT PUBG_Plugin:public QObject,public Interface_Appplication_Plugin
{
    Q_OBJECT
    Q_INTERFACES(Interface_Appplication_Plugin)
    Q_PLUGIN_METADATA(IID Interface_Appplication_Plugin_IID)
public:
    explicit PUBG_Plugin(QObject *parent = nullptr)
    {};
    void readPlugins(QString) override;
    void pubg_inside();
};

#endif // PUBG_PLUGIN_H

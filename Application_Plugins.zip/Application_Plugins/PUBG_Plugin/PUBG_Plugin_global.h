#ifndef PUBG_PLUGIN_GLOBAL_H
#define PUBG_PLUGIN_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(PUBG_PLUGIN_LIBRARY)
#  define PUBG_PLUGIN_EXPORT Q_DECL_EXPORT
#else
#  define PUBG_PLUGIN_EXPORT Q_DECL_IMPORT
#endif

#endif // PUBG_PLUGIN_GLOBAL_H

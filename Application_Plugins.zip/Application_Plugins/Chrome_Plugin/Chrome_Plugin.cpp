#include "Chrome_Plugin.h"

void Chrome_Plugin::readPlugins(QString crome)
{
    QString cromeString="mycrome";
    if(crome.compare(cromeString))
    {
        crome_inside();
        qDebug()<<"******Crome___app_____found________"<<Qt::endl;
    }
}

void Chrome_Plugin::crome_inside()
{
   qDebug()<<"*******Crome___Plugin____Is__Created__*********"<<Qt::endl;
}

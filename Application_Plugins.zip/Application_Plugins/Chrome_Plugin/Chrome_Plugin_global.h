#ifndef CHROME_PLUGIN_GLOBAL_H
#define CHROME_PLUGIN_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(CHROME_PLUGIN_LIBRARY)
#  define CHROME_PLUGIN_EXPORT Q_DECL_EXPORT
#else
#  define CHROME_PLUGIN_EXPORT Q_DECL_IMPORT
#endif

#endif // CHROME_PLUGIN_GLOBAL_H

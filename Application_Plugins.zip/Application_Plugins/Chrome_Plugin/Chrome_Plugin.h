#ifndef CHROME_PLUGIN_H
#define CHROME_PLUGIN_H

#include "Chrome_Plugin_global.h"
#include<Interface_Appplication_Plugin.h>
#include<QDebug>
#include<QObject>

class CHROME_PLUGIN_EXPORT Chrome_Plugin:public QObject,public Interface_Appplication_Plugin
{
    Q_OBJECT
    Q_INTERFACES(Interface_Appplication_Plugin)
    Q_PLUGIN_METADATA(IID Interface_Appplication_Plugin_IID)
public:
    explicit Chrome_Plugin(QObject *parent = nullptr)
    {};
    void readPlugins(QString) override;
    void crome_inside();
};

#endif // CHROME_PLUGIN_H

#include "Calculator_Plugin.h"

void Calculator_Plugin::readPlugins(QString cali)
{
    QString calString="mycalculator";
    if(cali.compare(calString))
    {
        calci_inside();
        qDebug()<<"******Calculator___app_____found________"<<Qt::endl;
    }
}

void Calculator_Plugin::calci_inside()
{
    qDebug()<<"*******Calculator___Plugin____Is__Created__*********"<<Qt::endl;
}



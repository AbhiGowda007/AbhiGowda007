#ifndef CALCULATOR_PLUGIN_H
#define CALCULATOR_PLUGIN_H

#include "Calculator_Plugin_global.h"
#include<Interface_Appplication_Plugin.h>
#include<QDebug>
#include<QObject>

class CALCULATOR_PLUGIN_EXPORT Calculator_Plugin:public QObject,public Interface_Appplication_Plugin
{
    Q_OBJECT
    Q_INTERFACES(Interface_Appplication_Plugin)
    Q_PLUGIN_METADATA(IID Interface_Appplication_Plugin_IID)
public:
    explicit Calculator_Plugin(QObject *parent = nullptr)
    {};

    void readPlugins(QString) override;
    void calci_inside();
};

#endif // CALCULATOR_PLUGIN_H
